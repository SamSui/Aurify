/**
 * Human-facing `/patent-review` command: a deterministic rubric review over
 * one project file or a directory of Markdown files. The handler reads the
 * target from disk, starts the fixed workflow script (host data — the model
 * cannot skip or reshape the review), writes `review/<label>.review.md`, and
 * returns a UI-only summary. `CommandResult` never enters model history; the
 * report reaches the model only when it later reads the file through the fs
 * tools, so "model-visible ⟺ logged" stays intact.
 * @module @deepseek-ai/dsh-command-patent-review
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { isReviewOutcome, renderReport, summarize } from './review.ts';
export { REVIEW_SCRIPT } from './script.ts';
export declare const name = "command-patent-review";
export declare const inject: string[];
/** One rubric scoring dimension with its banded scoring guide. */
export interface RubricDimension {
    key: string;
    title: string;
    weight: number;
    guide: Record<string, string>;
}
/** The versioned rubric document the review engine scores against. */
export interface RubricDocument {
    name: string;
    dimensions: RubricDimension[];
}
/** Absolute path of the shipped versioned rubric, resolved beside the package. */
export declare const RUBRIC_PATH: string;
/**
 * Load and validate the versioned rubric (a durable file boundary — parsed,
 * not trusted). Misconfiguration fails loud at load.
 * @param path - absolute rubric JSON path.
 * @returns the rubric document.
 */
export declare function loadRubric(path?: string): RubricDocument;
/** Model-facing `/patent-review` command configuration. */
export interface Config {
    /**
     * How many independent scoring passes run per rubric dimension. Two gives a
     * self-consistency signal (spread is visible in the report) at twice the
     * child count; one is the cheap mode. Validated to 1-5.
     */
    scoringPasses: number;
    /**
     * The patent project root: the base for relative review targets. Unset
     * resolves each invocation against the receiving agent's session cwd (the
     * workspace a web composition created the session in); set it explicitly
     * only when the fs world differs from that session workspace (e.g. a
     * composed `fs-local` cwd). The report folder anchors to the nearest
     * enclosing patent.yml project regardless.
     */
    projectRoot?: string;
}
/** Schemastery configuration for the review command. */
export declare const Config: z<Config>;
/**
 * Register `/patent-review` for every composed human-command adapter.
 * @param ctx - context carrying the command registry and the workflow engine.
 * @param config - deployment's scoring-pass count.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map