/**
 * Host-side review types and rendering: validation of the worker's returned
 * value (a worker boundary — validated, not trusted) and the pure markdown
 * report/summary renderers. Same input, same report.
 * @module
 */
/** One rubric dimension's collected pass scores, folded by the script. */
export interface ScoredDimension {
    key: string;
    title: string;
    weight: number;
    /** Each successful pass's 0-100 score, in pass order. */
    scores: number[];
    /** Rounded mean of {@link scores}; null when every pass failed. */
    average: number | null;
    /** Passes whose scoring child failed. */
    failedPasses: number;
    evidence: string[];
    suggestions: string[];
}
/** The script's materialized return value. */
export interface ReviewOutcome {
    /** Weight-renormalized mean over dimensions with collected scores; null when none. */
    overall: number | null;
    dimensions: ScoredDimension[];
    /** The claims↔description NLI phase; absent when the target carried no application set. */
    consistency?: ConsistencyOutcome | null;
}
/** One aggregated finding of the claims↔description consistency phase. */
export interface ConsistencyFinding {
    /** The claim number/text or the mismatched term the finding names. */
    claim: string;
    /** Why it is unsupported or mismatched, citing the description. */
    reason: string;
}
/** The NLI-style consistency phase's aggregated outcome. */
export interface ConsistencyOutcome {
    /** Rounded mean over the phase's child scores; null when every child failed. */
    score: number | null;
    /** Children that failed (of `passes × 2`). */
    failedPasses: number;
    /** Union of unsupported-claim/term findings across passes, first reason per claim. */
    unsupportedClaims: ConsistencyFinding[];
    evidence: string[];
    suggestions: string[];
}
/**
 * Runtime guard for the worker→host boundary.
 * @param value - the script's materialized return value.
 * @returns whether the value carries the expected review structure.
 */
export declare function isReviewOutcome(value: unknown): value is ReviewOutcome;
/**
 * Render the deterministic markdown report for one review run.
 * @param outcome - the validated script result.
 * @param fileLabel - the reviewed path, as the caller addressed it.
 * @param scope - whether the target was the whole project root ('project') or
 * a narrower file/directory ('partial'); the loop's score gate only accepts
 * whole-project reports, so the scope is stamped into the report body.
 * @returns the report body (no trailing newline; the writer adds one).
 */
export declare function renderReport(outcome: ReviewOutcome, fileLabel: string, scope?: 'project' | 'partial'): string;
/**
 * Render the UI-only command summary.
 * @param outcome - the validated script result.
 * @param reportPath - where the report was written, relative to the working directory.
 * @returns the summary text.
 */
export declare function summarize(outcome: ReviewOutcome, reportPath: string): string;
//# sourceMappingURL=review.d.ts.map