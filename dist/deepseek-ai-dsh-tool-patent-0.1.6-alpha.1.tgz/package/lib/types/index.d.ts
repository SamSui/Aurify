/**
 * Model-facing deterministic patent tools: the five-party alignment coverage
 * scorer that gates the Init dialogue, and the claims-and-abstract linter for
 * application drafting. Both are pure functions of their arguments. Named
 * exports preserve loader injection metadata.
 * @module @deepseek-ai/dsh-tool-patent
 */
import type { Context } from '@deepseek-ai/cordis';
export { computeCoverage } from './coverage.ts';
export type { Coverage, DimensionOutline } from './coverage.ts';
export { lintClaims, parseClaims, countAbstractChars, ABSTRACT_MAX_CHARS } from './claims-lint.ts';
export type { ClaimsLintResult, ParsedClaim, ClaimViolation } from './claims-lint.ts';
export declare const name = "tool-patent";
export declare const inject: string[];
/**
 * Register the `patent_brief_coverage` and `patent_claims_lint` tools on
 * `ctx.tools`.
 * @param ctx - registrant context carrying the tool registry.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map