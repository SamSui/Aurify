/**
 * Deterministic claims-and-abstract linter for a Chinese patent application
 * draft (CNIPA conventions). A pure function of its arguments: the model
 * supplies the drafted claims text (and the optional abstract text) and
 * receives per-claim structure and rule violations, mirroring how the
 * coverage scorer gates the Init dialogue.
 *
 * The rules are statutory-format minimums, not substantive examination:
 * numbering (C1), dependent-claim backward reference (C2), citation form
 * (C3), the multiple-dependent-reference base restriction (C4), the two-part
 * form hint for independent claims (C5), and the abstract length cap (A1).
 * @module
 */
/** One parsed claim's structure, derived from its citation prefix. */
export interface ParsedClaim {
    /** The claim's leading number. */
    number: number;
    /** The claim's full text (marker included), trimmed. */
    text: string;
    /** Independent (no citation prefix) or dependent (cites earlier claims). */
    kind: 'independent' | 'dependent';
    /** Claim numbers cited in the prefix, ascending as written. */
    references: number[];
    /** True when the prefix selects from several claims (任一项 form). */
    multiDependent: boolean;
}
/** One rule violation; `claim` is absent for whole-document rules (A1). */
export interface ClaimViolation {
    claim?: number;
    rule: string;
    severity: 'error' | 'warning';
    message: string;
}
/** Lint result: parsed claims, violations, and a count summary. */
export interface ClaimsLintResult {
    claims: ParsedClaim[];
    violations: ClaimViolation[];
    summary: {
        total: number;
        independent: number;
        dependent: number;
        errors: number;
        warnings: number;
    };
}
/** Abstract hard cap in characters (细则: 说明书摘要不超过 300 个字). */
export declare const ABSTRACT_MAX_CHARS = 300;
/**
 * Split the claims text into numbered claims. Text before the first marker is
 * ignored (headings like "权利要求书"); claims may span several lines.
 * @param claimsText - the drafted claims section.
 * @returns claims in document order; empty when no numbered claim is found.
 */
export declare function parseClaims(claimsText: string): ParsedClaim[];
/**
 * Count the abstract's chargeable characters: every non-whitespace character
 * (Chinese convention counts each character, punctuation included).
 * @param abstractText - the drafted abstract, or undefined when not supplied.
 * @returns the chargeable character count; 0 for absent input.
 */
export declare function countAbstractChars(abstractText: string | undefined): number;
/**
 * Lint a drafted claims section (and optional abstract) against the CNIPA
 * format minimums.
 * @param claimsText - the claims section text.
 * @param abstractText - the abstract text; the A1 rule is skipped when omitted.
 * @returns parsed claims, violations, and the count summary.
 */
export declare function lintClaims(claimsText: string, abstractText?: string): ClaimsLintResult;
//# sourceMappingURL=claims-lint.d.ts.map