/**
 * The patent-loop state assessor: one deterministic pass over a project
 * directory that names the first incomplete pipeline stage and the directive
 * for finishing it. The loop itself runs in the model's hands — call the
 * tool, execute the stage per its skills, call again — but the completion
 * verdict ("成稿交底书") belongs to this assessor, which reads only disk
 * facts (manifest, brief, chapters, experiment run log, figure files, review
 * reports, the exported docx), never the model's own claim of being done.
 * @module dsh-tool-patent/loop
 */
/** Pipeline stages in execution order; `done` is the completed verdict. */
export declare const LOOP_STAGES: readonly ["init", "align", "chapters", "experiments", "figures", "review", "export"];
/** One pipeline stage, or `done` when the disclosure is final. */
export type LoopStage = (typeof LOOP_STAGES)[number] | 'done';
/** One pending requirement found by the assessment pass. */
export interface LoopGap {
    /** The stage whose completion this gap belongs to. */
    stage: LoopStage;
    /** Human-readable description of what is missing. */
    detail: string;
}
/** The assessor's verdict for one project directory. */
export interface LoopState {
    /** Absolute project directory the assessment ran against. */
    projectRoot: string;
    /** Project display name: the manifest `name`, else the directory's basename. */
    projectName: string;
    /** Whether a patent project (patent.yml) exists at the root. */
    hasProject: boolean;
    /** First incomplete stage in pipeline order; `done` when nothing pends. */
    stage: LoopStage;
    /** True only when every pipeline gate passes — the 成稿 verdict. */
    complete: boolean;
    /** Every pending requirement in pipeline order (the roadmap, not just the stage). */
    gaps: LoopGap[];
    /** The directive for the current stage: what to do, which skills, which disciplines. */
    directive: string;
    /** Skill names to load before executing the current stage. */
    skills: string[];
    /** Whether the current stage may pause for user input (evaluation, interview). */
    mayNeedUser: boolean;
}
/**
 * Run one assessment pass over a project directory and produce the loop
 * state: the first incomplete stage, the full pending roadmap, and the
 * current stage's directive. Every verdict is a disk fact — a stage the
 * model believes finished but whose artifacts are missing stays pending.
 * @param projectDir - the project directory (resolved against the caller).
 * @returns the loop state; `complete` is true only when every gate passes.
 */
export declare function assessLoopState(projectDir: string): Promise<LoopState>;
//# sourceMappingURL=loop.d.ts.map