import type { ReactNode } from 'react';
import type { PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
/** Full component props of the Patent settings section. */
export type PatentSectionProps = PropsRuntime<'settings.section'> & PropsLocale<'patent'>;
/**
 * Render the Patent settings section: a discoverability surface for what the
 * bundle ships and how the environment-gated services turn on. Pure copy —
 * the gates it describes are host-process environment, which a browser
 * surface cannot read.
 * @param props - settings section slot props plus the patent locale seat.
 * @returns the static section body.
 */
export declare function PatentSection({ t }: PatentSectionProps): ReactNode;
//# sourceMappingURL=PatentSection.d.ts.map