/** `patent` namespace dictionaries for the two tool cards and the project dashboard tab. */
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Patent tool cards and the project dashboard tab copy. */
        patent: PatentKey;
    }
}
/** Dictionary namespace owned by the patent client half. */
export declare const NS = "patent";
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'coverage.title': string;
    'coverage.running': string;
    'coverage.failed': string;
    'coverage.stopped': string;
    'coverage.ready': string;
    'coverage.notReady': string;
    'coverage.alignment': string;
    'coverage.aligned': string;
    'coverage.notAligned': string;
    'coverage.raw': string;
    'lint.title': string;
    'lint.running': string;
    'lint.failed': string;
    'lint.stopped': string;
    'lint.pass': string;
    'lint.fail': string;
    'lint.total': string;
    'lint.independent': string;
    'lint.dependent': string;
    'lint.errors': string;
    'lint.warnings': string;
    'lint.violations': string;
    'lint.raw': string;
    'panel.title': string;
    'panel.guide': string;
    'panel.refresh': string;
    'panel.loading': string;
    'panel.unreadable': string;
    'panel.notProject': string;
    'panel.project': string;
    'panel.brief': string;
    'panel.application': string;
    'panel.claims': string;
    'panel.description': string;
    'panel.abstract': string;
    'panel.chapters': string;
    'panel.review': string;
    'panel.figures': string;
    'panel.stage': string;
    'panel.stage.align': string;
    'panel.stage.chapters': string;
    'panel.stage.experiments': string;
    'panel.stage.figures': string;
    'panel.stage.review': string;
    'panel.stage.export': string;
    'panel.stage.ready': string;
    'panel.threshold': string;
    'panel.partial': string;
    'panel.degraded': string;
    'review.title': string;
    'review.running': string;
    'review.report': string;
    'review.raw': string;
    'panel.empty': string;
};
/** The patent namespace key union. */
export type PatentKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'coverage.title': string;
    'coverage.running': string;
    'coverage.failed': string;
    'coverage.stopped': string;
    'coverage.ready': string;
    'coverage.notReady': string;
    'coverage.alignment': string;
    'coverage.aligned': string;
    'coverage.notAligned': string;
    'coverage.raw': string;
    'lint.title': string;
    'lint.running': string;
    'lint.failed': string;
    'lint.stopped': string;
    'lint.pass': string;
    'lint.fail': string;
    'lint.total': string;
    'lint.independent': string;
    'lint.dependent': string;
    'lint.errors': string;
    'lint.warnings': string;
    'lint.violations': string;
    'lint.raw': string;
    'panel.title': string;
    'panel.guide': string;
    'panel.refresh': string;
    'panel.loading': string;
    'panel.unreadable': string;
    'panel.notProject': string;
    'panel.project': string;
    'panel.brief': string;
    'panel.application': string;
    'panel.claims': string;
    'panel.description': string;
    'panel.abstract': string;
    'panel.chapters': string;
    'panel.review': string;
    'panel.figures': string;
    'panel.stage': string;
    'panel.stage.align': string;
    'panel.stage.chapters': string;
    'panel.stage.experiments': string;
    'panel.stage.figures': string;
    'panel.stage.review': string;
    'panel.stage.export': string;
    'panel.stage.ready': string;
    'panel.threshold': string;
    'panel.partial': string;
    'panel.degraded': string;
    'review.title': string;
    'review.running': string;
    'review.report': string;
    'review.raw': string;
    'panel.empty': string;
};
//# sourceMappingURL=locales.d.ts.map