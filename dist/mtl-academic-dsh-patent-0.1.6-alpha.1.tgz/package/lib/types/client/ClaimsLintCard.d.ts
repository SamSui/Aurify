import type { ToolCallViewProps } from '@deepseek-ai/dsh-client-ui-tool/client';
import type { PropsLocale } from '@deepseek-ai/dsh-client-ui-slots';
type ClaimsLintCardProps = ToolCallViewProps & PropsLocale<'patent'>;
/**
 * Render one `patent_claims_lint` call as a format-check card: the claim count
 * split, the violation list with rule chips, and the verdict. Settled cards
 * prefer the persisted presentation meta; sessions logged without it fall
 * back to parsing the rendered text, with the raw text in a disclosure.
 * @param props - keyed toolview payload plus the patent locale seat.
 * @returns the claims-lint card.
 */
export declare function ClaimsLintCard({ block, t }: ClaimsLintCardProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=ClaimsLintCard.d.ts.map