/**
 * The patent project overview's view model: raw workspace listings and the
 * patent.yml first page become the sections the dashboard tab draws. Pure
 * and synchronous — the body performs the reads, this derives the display.
 * @module
 */
import type { DirectoryListing } from './patent-face.ts';
/** One file entry as the overview lists it. */
export interface ProjectFile {
    readonly name: string;
    readonly size?: number;
}
/**
 * The pipeline stage the disk facts point at. Presence-based coarse read for
 * the dashboard only — freshness/fingerprint gates stay the patent_loop
 * tool's authority, so `ready` means "nothing pends on presence", not the
 * 成稿 verdict.
 */
export type LoopStageGuess = 'align' | 'chapters' | 'experiments' | 'figures' | 'review' | 'export' | 'ready';
/** One review report's parsed verdict, as the dashboard shows it. */
export interface ReviewReportView {
    readonly name: string;
    /** The parsed `总分`, or null when the first page carries none. */
    readonly score: number | null;
    /** The report stamps itself as a partial-target review. */
    readonly partial: boolean;
    /** A whole-project report whose score clears the effective threshold. */
    readonly passing: boolean;
}
/** The dashboard's coarse pipeline summary. */
export interface LoopSummary {
    readonly stage: LoopStageGuess;
    /** The effective score bar (reviewThreshold override, minus the degraded relaxation). */
    readonly threshold: number;
    /** reference/prior-art.md carries the 查新不可用 marker. */
    readonly degraded: boolean;
    readonly reports: readonly ReviewReportView[];
}
/** The whole dashboard's display state. */
export interface ProjectView {
    /** The workspace holds a patent project (patent.yml or the chapter layout present). */
    readonly isProject: boolean;
    /** patent.yml's `name` field, best-effort. */
    readonly projectName: string | null;
    /** patent.yml's `status` field, best-effort. */
    readonly projectStatus: string | null;
    /** brief.md exists at the root. */
    readonly brief: boolean;
    /** The eight chapter files, in chapter order, present and non-empty. */
    readonly chapters: readonly ProjectFile[];
    /** draftedCount: present chapters with content; total: the fixed eight. */
    readonly drafted: number;
    readonly total: 8;
    /** Application documents present under application/. */
    readonly application: {
        readonly claims: boolean;
        readonly description: boolean;
        readonly abstract: boolean;
    };
    /** Review reports (.md) under review/, by name. */
    readonly review: readonly string[];
    /** Final figure images (.png) at the figures/ root, in name order, each with its 08-drawings caption when one matches. */
    readonly figures: readonly {
        readonly name: string;
        readonly caption: string | null;
    }[];
    /** The coarse pipeline summary derived from the second-phase reads. */
    readonly loop: LoopSummary;
}
/**
 * Second-phase reads the loop summary consumes. Every field is optional —
 * the panel degrades to presence-only facts when a read failed or was
 * skipped, never blocking the dashboard on one missing file.
 */
export interface ProjectExtras {
    readonly briefText?: string | null;
    readonly effectText?: string | null;
    readonly priorArtText?: string | null;
    readonly experimentsReadmeText?: string | null;
    /** Whether each experiments/ subdirectory carries results/run-log.md (body-resolved, capped). */
    readonly experimentRunLogs?: readonly boolean[];
    readonly exportsListing?: DirectoryListing | null;
    /** First-page texts of the newest *.review.md reports (body-resolved, capped). */
    readonly reportTexts?: readonly {
        readonly name: string;
        readonly text: string | null;
    }[];
}
/**
 * Derive the dashboard sections from the workspace listings and patent.yml's first page.
 * @param root - the workspace root listing; null when it could not be read.
 * @param chapters - the chapters/ listing; null when the directory is absent.
 * @param review - the review/ listing; null when absent.
 * @param figures - the figures/ listing; null when absent.
 * @param application - the application/ listing; null when absent.
 * @param patentYml - patent.yml's first page text; null when the file is absent.
 * @param drawingsText - chapters/08-drawings.md's first page, for figure captions; null when absent.
 * @param extras - second-phase reads for the loop summary; every field optional.
 * @returns the display state.
 */
export declare function buildProjectView(root: DirectoryListing | null, chapters: DirectoryListing | null, review: DirectoryListing | null, figures: DirectoryListing | null, application: DirectoryListing | null, patentYml: string | null, drawingsText?: string | null, extras?: ProjectExtras): ProjectView;
//# sourceMappingURL=project-model.d.ts.map