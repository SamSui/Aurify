/**
 * View models for the two patent tool cards, derived solely from the durable
 * call slice (args, result content, presentation meta) so live and replay
 * renders stay identical. The structured `meta` path is authoritative; the
 * render-text parsers are the fallback for sessions logged on cores that
 * predate the presentation channel, kept aligned with the renderers in
 * `packages/patent/tool-patent/src/index.ts`.
 * @module
 */
/** Canonical coverage payload projected by `patent_brief_coverage`. */
export interface CoverageMeta {
    covered: string[];
    missing: string[];
    ready: boolean;
    coreFilled: {
        done: number;
        total: number;
    };
    aligned: boolean;
    alignmentCounts: {
        background: number;
        problem: number;
        effect: number;
    };
}
/** Canonical claims-lint payload projected by `patent_claims_lint`. */
export interface LintMeta {
    summary: {
        total: number;
        independent: number;
        dependent: number;
        errors: number;
        warnings: number;
    };
    violations: {
        claim?: number;
        rule: string;
        severity: 'error' | 'warning';
        message: string;
    }[];
}
/** Minimal structural face of the toolview block the models read. */
export interface ToolBlockLike {
    callId: string;
    /** Present marks the settled result node; a running call carries only args. */
    kind?: string;
    argsRaw?: string;
    call?: {
        name: string;
        argsRaw: string;
    } | null;
    content?: readonly {
        type: string;
        text?: string;
    }[];
    isError?: boolean;
    error?: {
        code?: string;
    } | null;
    meta?: unknown;
}
/** Card lifecycle, mirroring the shared tool-row states. */
export type CardState = 'running' | 'ok' | 'error' | 'stopped';
/** Chinese title per dimension key, matching the tool's chapter structure. */
export declare const DIMENSION_TITLES: Readonly<Record<string, string>>;
/** Core dimension keys in scoring order. */
export declare const CORE_DIMENSIONS: readonly ["field", "background", "problem", "solution", "effect"];
/**
 * Flatten durable result blocks under the generic Tool-row text contract.
 * @param block - the settled or running call slice.
 * @returns the joined text, or null when the call has no visible output.
 */
export declare function resultText(block: ToolBlockLike): string | null;
/**
 * Card state from the settled/failed/interrupted slice, shared by both cards.
 * @param block - the frozen call slice.
 * @returns the display state.
 */
export declare function cardState(block: ToolBlockLike): CardState;
/**
 * Parse the render-text fallback into a coverage payload; null when it drifts.
 * @param text - the model-visible result text.
 * @returns the coverage fields the text carries, minus the covered list.
 */
export declare function parseCoverageText(text: string): Omit<CoverageMeta, 'covered'> | null;
/** One settled or running coverage card's view. */
export interface CoverageView {
    state: CardState;
    meta: CoverageMeta | null;
    /** Core dimensions submitted with the call while still running (keys). */
    submitted: string[];
    text: string | null;
}
/**
 * Derive the coverage card view without consulting anything but the block.
 * @param block - the frozen call slice.
 * @returns the coverage card view.
 */
export declare function coverageView(block: ToolBlockLike): CoverageView;
/**
 * Parse the render-text fallback into a lint payload; null when it drifts.
 * @param text - the model-visible result text.
 * @returns the lint summary with the violations the text carries.
 */
export declare function parseLintText(text: string): Omit<LintMeta, 'violations'> & {
    violations: LintMeta['violations'];
} | null;
/** One settled or running claims-lint card's view. */
export interface LintView {
    state: CardState;
    meta: LintMeta | null;
    text: string | null;
}
/**
 * Derive the claims-lint card view without consulting anything but the block.
 * @param block - the frozen call slice.
 * @returns the claims-lint card view.
 */
export declare function lintView(block: ToolBlockLike): LintView;
/** Canonical review payload projected by `patent_review`. */
export interface ReviewMeta {
    kind: 'success' | 'error';
    summary: string;
    report: string;
    overall?: number;
    dimensions?: {
        key: string;
        title: string;
        weight: number;
        average: number | null;
        failedPasses: number;
    }[];
}
/** One settled or running review card's view. */
export interface ReviewView {
    state: CardState;
    meta: ReviewMeta | null;
    /** The target argument while still running. */
    target: string | null;
    text: string | null;
}
/**
 * Derive the review card view without consulting anything but the block. The
 * render-text fallback carries only the summary line (the report path), so a
 * session logged without the presentation channel shows the summary in the
 * disclosure; the dimension bars need the meta.
 * @param block - the frozen call slice.
 * @returns the review card view.
 */
export declare function reviewView(block: ToolBlockLike): ReviewView;
//# sourceMappingURL=models.d.ts.map