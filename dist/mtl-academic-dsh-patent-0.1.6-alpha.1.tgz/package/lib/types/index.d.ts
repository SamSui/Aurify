/**
 * Patent bundle asset carrier: registers the shipped patent SKILL.md assets as
 * runtime skills so the writing procedures and quality standards reach the
 * model's catalog without any filesystem discovery root, and pins the
 * discussion-stage sampling temperature on the profile's top-level sessions.
 * The composition rows live in cordis.patch.yml; this plugin contributes the
 * package's own skills and sampling default.
 * @module @mtl-academic/dsh-patent
 */
import type { Context } from '@deepseek-ai/cordis';
export { SKILLS_DIR, loadBundledSkills, parseSkillFile } from './skills.ts';
export { DISCUSSION_TEMPERATURE } from './sampling.ts';
export declare const name = "patent-assets";
export declare const inject: string[];
/**
 * Register every shipped skill on the skills registry and pin the
 * discussion-stage sampling temperature on top-level sessions.
 * @param ctx - Cordis context carrying the skills registry and event dispatch.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map