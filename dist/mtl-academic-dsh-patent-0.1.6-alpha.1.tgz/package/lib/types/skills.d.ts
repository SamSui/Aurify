/**
 * Loader for the patent bundle's shipped SKILL.md assets: one directory under
 * `skills/` per skill, frontmatter carries the routing metadata, the body is
 * the instruction content. Registered as runtime skills at plugin load, so the
 * assets ship with the package and need no filesystem discovery root.
 * @module
 */
import type { SkillRegistration } from '@deepseek-ai/dsh-skill';
/** The package's shipped skill directories, resolved at runtime. */
export declare const SKILLS_DIR: string;
/**
 * Load every shipped skill directory.
 * @param dir - the directory whose immediate subdirectories each hold a SKILL.md.
 * @returns one registration per skill directory, sorted by name for a
 * prefix-stable catalog order.
 */
export declare function loadBundledSkills(dir?: string): SkillRegistration[];
/**
 * Parse one SKILL.md into a runtime skill registration.
 * @param filePath - absolute path of the SKILL.md file.
 * @returns the registration, with a directory resource base so relative
 * references (e.g. `references/*.md`) resolve beside the file.
 */
export declare function parseSkillFile(filePath: string): SkillRegistration;
//# sourceMappingURL=skills.d.ts.map